import cx_Freeze

# base = "Win32GUI" allows your application to open without a console window
executables = [cx_Freeze.Executable('rankedres.py')]

cx_Freeze.setup(
    name = "temp",
    options = {"build_exe" : 
        {"packages" : ["tkinter","os", "time", "random"], "include_files" : ['images/', 'savefiles/', 'currentfile', 'defense.txt', 'attack.txt']}},
    executables = executables
)