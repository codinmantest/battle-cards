import tkinter as tk
from random import randint


cardlist = []
basecards = []

class Card:
    def __init__(self, name, rarity, ctype = 'basic', desc = '', power_multi=1, health_multi=1, bpm=1, bhm=1, border='normal'):
        self.name = name
        self.rarity = rarity
        self.ctype = ctype
        self.border = border
        self.desc = desc

        cardlist.append(self)

def make_card(name, rarity, ctype = 'basic', power_multi=1, health_multi=1, bpm=1, bhm=1, desc=''):
    base = Card(name, rarity, ctype, desc, power_multi, health_multi, bpm, bhm)
    return base


farmer = make_card('Farmer', 2)
ghoul = make_card('Ghoul', 4)
wolf = make_card('Wolf', 8, desc="Lower the enemy's damage by 10% on entry")
bear = make_card('Bear', 20, desc="Attacks inflict a bleed for 10% damage that lasts 2 turns")
falcon = make_card('Falcon', 50, desc='This card cannot miss')
vampire = make_card('Vampire', 100, desc='Heal 25% of damage dealt after attacking')
samurai = make_card('Samurai', 200, desc='On entry, strike the enemy for 50% damage')
knight = make_card('Knight', 500, desc='Block 25% of damage taken')
orc = make_card('Orc', 800, desc='Deal 30% more damage, but take 10% recoil')
wyvern = make_card('Wyvern', 1_000, desc='Attacks apply a burn for 20% damage that lasts 2 turns')
griffin = make_card('Griffin', 1_250, desc='Gain 15% stats on entry')
gunslinger = make_card('Gunslinger', 8_000, desc='Attacks inflict a mark. Deal 150% damage to marked cards')
dragon = make_card('Dragon', 20_000, desc="Deal 70% damage, but apply a burn for 2 turns that deals 40% damage")
fiend = make_card('Fiend', 20_000, desc='Gain 10% dodge chance every turn, up to 30%')
nurse = make_card('Nurse', 50_000, desc="While alive, heal the active ally by 20% of their max health each turn. Doesn't stack")
porcupine = make_card('Porcupine', 200_000, desc='Attacks against this card take 50% recoil damage')

brunhilde = make_card('Brunhilde', 5_000, 'Boss', desc="On entry, grant all allies a shield equal to 25% of this card's max health")
berserker = make_card('Berserker', 20_000, 'Boss', desc="After every turn, gain 10% damage and 10% damage reduction. Max 3 stacks")
thor = make_card('Thor', 100_000, 'Boss', desc='Every turn, deal 10% damage to all opponents')
kraken = make_card('Kraken', 500_000, 'Boss', desc='Attack 3 times dealing 50% damage')

spartan = make_card('Spartan', 50_000, 'Boss', desc='Gain 10% stats for each living ally on entry')
alexander = make_card('Alexander', 200_000, 'Boss', desc='This card has a 30% chance to block attacks')
achilles = make_card('Achilles', 800_000, 'Boss', desc="Attacks pierce dealing 50% damage to the next enemy")
hercules = make_card('Hercules', 3_500_000, 'Boss', desc="Each turn gain a stack giving 20% health and a 5% heal. Max 3 stacks")

imp = make_card('Imp', 1_000_000, 'Boss', desc='Attacks inflict a brand. Enemies take 40% more damage per brand')
demon = make_card('Demon', 4_000_000, 'Boss', desc='While active, all enemies burn for 20% damage per turn')
cerberus = make_card('Cerberus', 15_000_000, 'Boss', desc="While alive, enemies take 50% more burn damage")
hades = make_card('Hades', 50_000_000, 'Boss', desc='Deal 50% more damage. Uppon killing an enemy, heal 25% of max hp')

fire_knight = make_card('Fire_knight', 15_000_000, 'Boss', desc='Alternate between dealing 50% fire damage for 2 turns and dealing 130% damage')
water_knight = make_card('Water_knight', 80_000_000, 'Boss', desc='Alternate between healing 50% of damage dealt and block 25% damage')
dark_knight = make_card('Dark_knight', 250_000_000, 'Boss', desc="On entry, sacrifice 50% of the next card's health and gain it as damage")
holy_knight = make_card('Holy_knight', 1_000_000_000, 'Boss', desc="Revive with max health on first death")

famine = make_card('Famine', 100_000_000, 'Boss', desc='While active, enemies lose 10% max health per turn')
war = make_card('War', 400_000_000, 'Boss', desc='Gain 50% damage every turn')
death = make_card('Death', 1_200_000_000, 'Boss', desc='While alive, execute enemies below 25% health')
conquest = make_card('Conquest', 3_500_000_000, 'Boss', desc='Gain 10% stats for each fallen ally on entry and after every kill')

hero = make_card('Hero', 50_000, 'Market', desc='Increase damage by 50% of missing health')
commander = make_card('Commander', 1_000_000, 'Market', desc='On entry, all friendly cards gain 15% stats')
assassin = make_card('Assassin', 35_000_000, 'Market', desc="25% chance to dodge and inflict poison dealing 10% damage")
#kaiju = make_card('Kaiju', 200_000_000, 'Market')

minotaur = make_card('Minotaur', 80_000, 'Dungeon', desc='Gain 35% damage reduction for 2 turns on entry')
#Minotaur = make_card('Minotaur', 80_000, 'Dungeon', desc='Gain 35% damage reduction for 2 turns on entry')


class BattleCard:
    def __init__(self, card, hp=None, dmg=None):
        self.card = card
        self.hp = hp
        self.dmg = dmg
        if hp == None:self.hp=self.card.base_health
        if dmg == None:self.dmg = self.card.base_power
        self.maxhp = self.hp
        self.name = self.card.name
        self.basehp= self.hp
        self.basedmg = self.dmg

        self.effects = {
            'Burn':[],
            'Bleed':[],
            'Poisons':[],
            'Brand': 0,
            'nh': False,
            'Mark': 0,
            'tc': 0
        }
       
def before_attack(dmg, cards, ecards, cc, ce):

    try:
        if not cards[cc].name in ['Falcon']:
            if randint(1, 100) <= ecards[ce].effects['fdc']:dmg=0
            if randint(1, 100) <= 25 and ecards[ce].name == 'Assassin':dmg=0;cards[cc].effects['Poisons'].append([ecards[ce].dmg, 100])
    except:pass
    
    try:dmg*=1-(.1*ecards[ce].effects['berserk'])
    except:pass

    if cards[cc].name == 'Orc':dmg = int(dmg*1.3)
    if cards[cc].name == 'Kraken': dmg = int(dmg*.5)
    if cards[cc].name == 'Dragon': dmg = int(dmg*.7)
    if cards[cc].name == 'Hades': dmg = int(dmg*1.5)
    if cards[cc].name == 'Hero': dmg += int((cards[cc].maxhp - cards[cc].hp)*.5)
 
    if ecards[ce].name == 'Knight':dmg = int(dmg*.75) 

    if ecards[ce].name == 'Alexander' and randint(1,10) <=3:dmg = 0

    if cards[cc].name == 'Gunslinger' and ecards[ce].effects['Mark'] > 0:dmg = int(dmg*1.5)

    dmg *= 1+ecards[ce].effects['Brand']*.4

    try:
        if ecards[ce].effects['mb'] > 0:dmg = int(dmg*.65)
    except:pass

    if cards[cc].name == 'Fire_knight' and cards[cc].effects['tc'] % 2 == 1:dmg = int(dmg*1.3)
    if ecards[ce].name == 'Water_knight' and ecards[ce].effects['tc'] % 2 == 1:dmg = int(dmg*.75)
    
    try:
        if ecards[ce].effects['shield'] > 0:
            if ecards[ce].effects['shield'] > dmg:ecards[ce].effects['shield']-=dmg;dmg=0
            else:dmg-=ecards[ce].effects['shield'];ecards[ce].effects['shield']=0
    except:pass

    return dmg

def fight_effects(cards, ecards, cc, ce):
    cards[cc].effects['tc'] += 1
    bm=1
    for card in ecards:
        if card.name == 'Cerberus' and card.hp > 0:bm*=1.5

    for card in cards:
        card.effects['tc'] += 1
        for bleed in card.effects['Bleed']:
            if bleed[1] > 0:card.hp -= bleed[0];bleed[1]-=1
        for burn in card.effects['Burn']:
            if burn[1] > 0:card.hp -= burn[0]*bm;burn[1]-=1
        for poison in card.effects['Poisons']:
            if poison[1] > 0:card.hp -= poison[0];poison[1]-=1
        if card.effects['nh']:
            heal = min(card.maxhp-card.hp, int(card.maxhp*.2))
            card.hp += heal
            card.effects['nh'] = False
        try:card.effects['mb'] -= 1
        except:pass
    return cards

def after_attack(dealt, cards, ecards, cc, ce, loop=True):
    if cards[cc].name == 'Berserker':
        try:
            if cards[cc].effects['berserk'] < 3: cards[cc].effects['berserk']+=1;cards[cc].dmg+=int(cards[cc].dmg*.1)
        except:cards[cc].effects['berserk'] = 1;cards[cc].dmg+=int(cards[cc].dmg*.1)

    if cards[cc].name == 'Thor':
        for _, card in enumerate(ecards):
            if card.hp<=0:continue
            dmg = cards[cc].dmg*.1
            dmg = before_attack(dmg, cards, ecards, cc, _)
            ecards[_].hp -= dmg
            #cards, ecards = after_attack(dmg, cards, ecards, cc, _)

    for card in cards:
        if card.name == 'Nurse' and card.hp > 0:
            cards[cc].effects['nh'] = True 
            #try:card.effects['shield'] += heal
            #except:card.effects['shield'] = heal
            
    if cards[cc].name == 'Achilles' and ce+1<len(ecards):
        if ecards[ce+1].hp > 0:
            dmg = cards[cc].dmg*.5
            dmg = before_attack(dmg, cards, ecards, cc, ce+1)
            ecards[ce+1].hp -= dmg
            #cards, ecards = after_attack(dmg, cards, ecards, cc, _)

    if cards[cc].name == 'Vampire':
        heal = min(cards[cc].maxhp-cards[cc].hp, int(dealt*.25))
        cards[cc].hp += heal

    if cards[cc].name == 'Orc':cards[cc].hp -= int(dealt*.1)
    
    if cards[cc].name == 'Bear':ecards[ce].effects['Bleed'].append([cards[cc].dmg*.1, 2])
    #if cards[cc].name == 'Cerberus':ecards[ce].effects['Bleed'].append([cards[cc].dmg*.4, 2])

    if cards[cc].name == 'Wyvern':ecards[ce].effects['Burn'].append([cards[cc].dmg*.2, 2])
    if cards[cc].name == 'Dragon':ecards[ce].effects['Burn'].append([cards[cc].dmg*.4, 2])

    if cards[cc].name == 'Demon':
        for card in ecards:card.effects['Burn'].append([cards[cc].dmg*.2, 1])
    
    if cards[cc].name == 'Kraken' and loop:
        for i in range(2):
            dmg = cards[cc].dmg*.5
            dmg = before_attack(dmg, cards, ecards, cc, ce)
            ecards[ce].hp -= dmg
            cards, ecards = after_attack(dmg, cards, ecards, cc, ce, False)

    if cards[cc].name == 'Hercules':
        try:heal = min(cards[cc].maxhp-cards[cc].hp, int(dealt*.05*min(3, cards[cc].effects['Hercules'])));cards[cc].hp += heal
        except:pass
        try:cards[cc].effects['Hercules']+=1
        except:cards[cc].effects['Hercules']=1
        if cards[cc].effects['Hercules'] <= 3:
            cards[cc].hp *= 1.2
            cards[cc].maxhp *= 1.2

    if cards[cc].name == 'Imp':ecards[ce].effects['Brand'] += 1
    if cards[cc].name == 'Gunslinger':ecards[ce].effects['Mark'] += 1

    if cards[cc].name == 'Fiend':
        try: cards[cc].effects['fdc'] = min(30, cards[cc].effects['fdc']+10)
        except:cards[cc].effects['fdc'] = 10

    if ecards[ce].name == 'Porcupine':
        cards[cc].hp -= int(dealt*.5)

    if cards[cc].name == 'Famine':
        for c in ecards:
            c.hp = int(c.hp*.9)
            c.maxhp = int(c.maxhp*.9)

    if cards[cc].name == 'War':
        cards[cc].dmg = int(cards[cc].dmg*1.5)

    for c in cards:
        if c.name == 'Death' and c.hp > 0:
            for e in ecards:
                if e.hp < e.maxhp*.25:e.hp = 0

    if cards[cc].name == 'Fire_knight' and cards[cc].effects['tc'] % 2 == 0:ecards[ce].effects['Burn'].append([int(cards[cc].dmg*.5), 2])
    if cards[cc].name == 'Water_knight' and cards[cc].effects['tc'] % 2 == 0:
        heal = min(cards[cc].maxhp-cards[cc].hp, int(dealt*.5))
        cards[cc].hp += heal

    if cards[cc].name == 'Dark_knight':
        try:
            dmg=int(cards[cc+1].hp*.5)
            cards[cc+1].hp = dmg
            cards[cc].dmg += dmg
        except:pass

    return cards, ecards

def on_entry(cards, ecards, cc, ce):
    if cards[cc].name == 'Samurai':
        dmg = cards[cc].dmg*.5
        dmg = before_attack(dmg, cards, ecards, cc, ce)
        ecards[ce].hp -= dmg
        cards, ecards = after_attack(dmg, cards, ecards, cc, ce)

    if cards[cc].name == 'Wolf':
        ecards[ce].dmg=int(ecards[ce].dmg*.9)

    if cards[cc].name == 'Brunhilde':
        for card in cards:
            try:card.effects['shield'] += cards[cc].maxhp*.25
            except:card.effects['shield'] = cards[cc].maxhp*.25

    if cards[cc].name == 'Spartan':
        for card in cards:
            if card.hp > 0 and card != cards[cc]:cards[cc].hp+=int(cards[cc].basehp*.1);cards[cc].dmg+=int(cards[cc].basedmg*.1);cards[cc].maxhp+=int(cards[cc].basehp*.1)

    if cards[cc].name == 'Griffin':cards[cc].hp = int(cards[cc].hp * 1.15);cards[cc].maxhp = int(cards[cc].maxhp * 1.15);cards[cc].dmg = int(cards[cc].dmg * 1.15)

    if cards[cc].name == 'Commander':
        for card in cards:
            card.hp = int(card.hp*1.15+.01)
            card.maxhp = int(card.maxhp*1.15+.01)
            card.dmg = int(card.dmg*1.15+.01)
            
    if cards[cc].name == 'Conquest':
        amt=1
        for c in cards:
            if c.hp <= 0:amt+=.1
        cards[cc].hp = int(cards[cc].hp*amt)
        cards[cc].maxhp = int(cards[cc].maxhp*amt)
        cards[cc].dmg = int(cards[cc].dmg*amt)

    if cards[cc].name == 'Minotaur':
        cards[cc].effects['mb'] = 3

    if cards[cc].name == 'Dark_knight':
        try:
            dmg=int(cards[cc+1].hp*.5)
            cards[cc+1].hp = dmg
            cards[cc].dmg += dmg
        except:pass

    return cards, ecards

def killed_enemy(cards, ecards, cc, ce):

    if ecards[ce].name == 'Holy_knight':
        try:ecards[ce].effects['revive'] += 1
        except:
            ecards[ce].effects['revive'] = 0
            #ecards[ce].maxhp = int(ecards[ce].maxhp*1.2)
            #ecards[ce].dmg = int(ecards[ce].dmg*1.2)
            ecards[ce].hp = ecards[ce].maxhp
            return cards, ecards


    if cards[cc].name == 'Hades':
        heal = min(cards[cc].maxhp-cards[cc].hp, int(cards[cc].maxhp*.25))
        cards[cc].hp += heal

    
    if cards[cc].name == 'Conquest':
        amt=1
        for c in cards:
            if c.hp <= 0:amt+=.1
        cards[cc].hp = int(cards[cc].hp*amt)
        cards[cc].maxhp = int(cards[cc].maxhp*amt)
        cards[cc].dmg = int(cards[cc].dmg*amt)


    return cards, ecards

def fight(cards, ecards, context=None):
    if len(cards) == 0 or len(ecards) == 0:return

    turn = True
    turns = 0

    cc = 0
    ce = 0

    cards, ecards = on_entry(cards, ecards, cc, ce)
    ecards, cards = on_entry(ecards, cards, ce, cc)

    while True:
        turns += 1
        if turns == 100:return 0
        
        while cards[cc].hp <= 0 or ecards[ce].hp <= 0:

            if cards[cc].hp <= 0:
                ecards, cards = killed_enemy(ecards, cards, ce, cc)
                if cards[cc].hp <= 0:
                    cc += 1
                    if cc >= len(cards):return 0
                    cards, ecards = on_entry(cards, ecards, cc, ce)
            
            else:
                cards, ecards = killed_enemy(cards, ecards, cc, ce)
                if ecards[ce].hp <= 0:
                    ce += 1
                    if ce >= len(ecards):return 1
                    ecards, cards = on_entry(ecards, cards, ce, cc)
            
        if turn:
            dmg = cards[cc].dmg
            dmg = before_attack(dmg, cards, ecards, cc, ce)
            ecards[ce].hp -= dmg
            cards, ecards = after_attack(dmg, cards, ecards, cc, ce)
            cards = fight_effects(cards, ecards, cc, ce)
                
        else:

            dmg = ecards[ce].dmg
            dmg = before_attack(dmg, ecards, cards, ce, cc)
            cards[cc].hp -= dmg
            ecards, cards = after_attack(dmg, ecards, cards, ce, cc)
            ecards = fight_effects(ecards, cards, ce, cc)

        turn = not turn


### RANKED

def expected(r_home, r_away, home_adv=0):
    return 1 / (1 + 10 ** ((r_away - (r_home + home_adv)) / 400))

attackteams = []
defenseteams = []

teams = 5000
loops = 500

for i in range(teams):
    
    c1 = cardlist[randint(0,len(cardlist)-1)]
    c2 = cardlist[randint(0,len(cardlist)-1)]
    c3 = cardlist[randint(0,len(cardlist)-1)]
    c4 = cardlist[randint(0,len(cardlist)-1)]

    attackteams.append([1500, [c1,c2,c3,c4]])
    defenseteams.append([1500, [c1,c2,c3,c4]])


customteams = [
    [commander, hades, hades, nurse],
    [commander, brunhilde, hercules, nurse], 
    [commander, demon, achilles, nurse],
    [commander, demon, demon, achilles],
    [brunhilde, famine, war, nurse],
    [commander, commander, commander, conquest],
    [brunhilde, brunhilde, brunhilde, knight],
    [commander, achilles, minotaur, conquest],
    [commander, achilles, conquest, minotaur],
    [commander, dark_knight, holy_knight, nurse]
]
#customteams = []

for t in customteams:
    attackteams.append([0, t])
    defenseteams.append([0, t])


def pos_opp(elo):
    p = []
    while len(p) < 5:
        r = 50
        for t in defenseteams:
            #if t[0] - elo < r or t[0] - elo > -r:p.append(t)
            if t[0] - elo < 99999 or t[0] - elo > -r:p.append(t)
        r*=2
    return p

def def_opp(elo):
    p = []
    while len(p) < 5:
        r = 50
        for t in attackteams:
            if t[0] - elo < r or t[0] - elo > -r:p.append(t)
        r*=2
    return p

iii=0
for i in range(loops):
    for t in attackteams:
        possopp = pos_opp(t[0])
        opp = possopp[randint(0, len(possopp)-1)]
        f = fight(
            [BattleCard(c, 200, 100) for c in t[1]],
            [BattleCard(c, 200, 100) for c in opp[1]]
        )
        res = 20*(f - expected(t[0], opp[0]))
        t[0] += res
        opp[0] -= res
    """for t in defenseteams:
        possopp = def_opp(t[0])
        opp = possopp[randint(0, len(possopp)-1)]
        f = fight(
            [BattleCard(c, 200, 100) for c in opp[1]],
            [BattleCard(c, 200, 100) for c in t[1]]
        )
        res = -20*((f - expected(t[0], opp[0])))
        t[0] += res
        opp[0] -= res"""
    iii+=1
    print(f'{round(iii/loops*100, 1)}%')


print("Sorting results...")

"""
iii=0
for at in attackteams:
    for dt in defenseteams:
        f = fight(
            [BattleCard(c, 200, 100) for c in at[1]],
            [BattleCard(c, 200, 100) for c in dt[1]]
        )
        res = 20*(f - expected(at[0], dt[0]))
        at[0] += res
        dt[0] -= res
        i+=1

    iii+=1
    print(f'{round(iii/amt*100, 1)}%')
"""
fat = []
fdt = []

#print(attackteams)

for t in attackteams:
    _=0
    for _,ot in enumerate(fat):
        if int(t[0]) < ot[0]:fat.insert(_, [int(t[0]), [c.name for c in t[1]]]);break
    else:fat.append([int(t[0]), [c.name for c in t[1]]])
for t in defenseteams:
    _ = 0
    for _,ot in enumerate(fdt):
        if int(t[0]) < ot[0]:fdt.insert(_, [int(t[0]), [c.name for c in t[1]]]);break
    else:fdt.append([int(t[0]), [c.name for c in t[1]]])

print('Ranking cards...')
capp = {}
for t in fat:
    for c in t[1]:
        try:
            for _, ct in enumerate(capp[c]):
                if t[0] > ct:capp[c].insert(_, t[0]);break
            else:capp[c].append(t[0])
        except:
            capp[c] = [t[0]]

best_cards = []

for c in capp:
    sum = 0
    l = 0
    for _,n in enumerate(capp[c]):
        sum+=n*(.95**_);l += .95**_
        #sum+=n*(1**_);l += 1**_
    avg = sum / l

    _ = 0
    for _,ot in enumerate(best_cards):
        if int(avg) < ot[0]:best_cards.insert(_, [int(avg), c]);break
    else:best_cards.append([int(avg), c])

#print(best_cards[-3], best_cards[-2], best_cards[-1])
#print(best_cards)
print()
ranks =     ['F',   'D-',   'D',    'D+',   'C-',   'C',    'C+',   'B-',   'B',
             'B+',  'A-',   'A',    'A+',   'S',    'SS',   'SSS', '']
rankreq =   [0,     1450,   1500,   1550,   1600,   1630,   1660,   1700,   1730,   
             1760,  1800,   1830,   1860,   1900,   2000,   2100,   100000]
rankreq = [v+200 for v in rankreq]
for v in best_cards:
    for r in range(len(ranks)):
        if v[0] < rankreq[r]:print(ranks[r-1], v[1]);break
print()
print(fat[-3], fat[-2], fat[-1])
print(f'\n')
print(fdt[-3], fdt[-2], fdt[-1])

import os
path = os.path.dirname(__file__)+'/'
w1 = open(path+'defense.txt', 'w')
w1.write(str(fdt))
w1.close()
w1 = open(path+'attack.txt', 'w')
w1.write(str(fat))
w1.close()


#print(defenseteams)